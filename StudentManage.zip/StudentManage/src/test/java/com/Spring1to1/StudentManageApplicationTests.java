package com.Spring1to1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentManageApplicationTests {

	@Test
	void contextLoads() {
	}

}
