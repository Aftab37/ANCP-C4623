package com.Spring1to1.service;

public class NotFoundException {

}
