package com.Spring1to1.repos;
import com.Spring1to1.entity.Student;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
	
	List<Student> findByAge(int age);
	List<Student> findByid(int id);
}
