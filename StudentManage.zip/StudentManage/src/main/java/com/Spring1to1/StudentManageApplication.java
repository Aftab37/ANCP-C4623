package com.Spring1to1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentManageApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentManageApplication.class, args);
		System.out.println("This is student DataBase:");
	
	}

}
